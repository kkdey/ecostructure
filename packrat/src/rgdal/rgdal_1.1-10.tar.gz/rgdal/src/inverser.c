/* Copyright (c) 2016 Barry Rowlingson */

#include <projects.h>

int inversetest(PJ *P){
  return (P->inv ? 1: 0);

}


