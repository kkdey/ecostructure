BiocGenerics:::testPackage("BiocStyle")
