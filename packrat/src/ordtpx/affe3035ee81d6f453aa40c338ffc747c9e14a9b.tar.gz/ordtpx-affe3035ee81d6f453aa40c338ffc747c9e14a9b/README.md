# ordtpx
R package for topic model on ordered features.

This is a modification of the `maptpx` package by Matt Taddy (Check `On Estimation and Selection of Topic Models`). But we assume the topics to have a smooth pattern across the features based on the ordering and hope
to capture that structure through a multi-resolution approach. 
